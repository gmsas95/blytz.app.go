package product

import (
	"context"
	"time"

	"github.com/google/uuid"
)

// Status represents product status
type Status string

const (
	StatusDraft     Status = "draft"
	StatusActive    Status = "active"
	StatusSold      Status = "sold"
	StatusCancelled Status = "cancelled"
)

// Product represents a product in the marketplace
type Product struct {
	ID             uuid.UUID
	SellerID       uuid.UUID
	CategoryID     uuid.UUID
	Title          string
	Description    string
	Condition      string // 'new', 'like_new', 'good', 'fair'
	StartingPrice  float64
	ReservePrice   *float64
	BuyNowPrice    *float64
	Images         []string
	VideoURL       string
	Specifications map[string]interface{}
	ShippingInfo   map[string]interface{}
	Status         Status
	Featured       bool
	ViewCount      int
	Rating         float64
	ReviewCount    int
	IsFlash        bool
	IsHot          bool
	FlashEnd       *time.Time
	CreatedAt      time.Time
	UpdatedAt      time.Time
}

// Category represents a product category
type Category struct {
	ID          uuid.UUID
	Name        string
	Slug        string
	Description string
	ImageURL    string
	ParentID    *uuid.UUID
	SortOrder   int
	IsActive    bool
	CreatedAt   time.Time
	UpdatedAt   time.Time
}

// SearchCriteria represents product search parameters
type SearchCriteria struct {
	CategoryID    *uuid.UUID
	SellerID      *uuid.UUID
	Status        *Status
	MinPrice      *float64
	MaxPrice      *float64
	SearchQuery   string
	Featured      bool
	FlashSale     bool
	HotProducts   bool
	SortBy        string // 'price_asc', 'price_desc', 'newest', 'popular'
	Page          int
	PageSize      int
}

// Repository defines the product repository interface
type Repository interface {
	// Commands
	Create(ctx context.Context, product *Product) error
	Update(ctx context.Context, product *Product) error
	Delete(ctx context.Context, id uuid.UUID) error
	IncrementViewCount(ctx context.Context, id uuid.UUID) error
	
	// Queries
	GetByID(ctx context.Context, id uuid.UUID) (*Product, error)
	GetBySeller(ctx context.Context, sellerID uuid.UUID, page, pageSize int) ([]*Product, int, error)
	Search(ctx context.Context, criteria SearchCriteria) ([]*Product, int, error)
	GetFlashProducts(ctx context.Context, limit int) ([]*Product, error)
	GetHotProducts(ctx context.Context, limit int) ([]*Product, error)
	
	// Categories
	CreateCategory(ctx context.Context, category *Category) error
	UpdateCategory(ctx context.Context, category *Category) error
	GetCategoryByID(ctx context.Context, id uuid.UUID) (*Category, error)
	GetCategoryBySlug(ctx context.Context, slug string) (*Category, error)
	GetCategories(ctx context.Context, parentID *uuid.UUID) ([]*Category, error)
}

// Cache defines product caching interface
type Cache interface {
	GetProduct(ctx context.Context, id uuid.UUID) (*Product, error)
	SetProduct(ctx context.Context, product *Product, ttl time.Duration) error
	DeleteProduct(ctx context.Context, id uuid.UUID) error
	GetSearchResults(ctx context.Context, cacheKey string) ([]*Product, error)
	SetSearchResults(ctx context.Context, cacheKey string, products []*Product, ttl time.Duration) error
}
package payment

import (
	"context"
	"time"

	"github.com/google/uuid"
)

// Status represents payment status
type Status string

const (
	StatusPending    Status = "pending"
	StatusProcessing Status = "processing"
	StatusCompleted  Status = "completed"
	StatusFailed     Status = "failed"
	StatusRefunded   Status = "refunded"
	StatusCancelled  Status = "cancelled"
)

// Method represents payment method
type Method string

const (
	MethodCard   Method = "credit_card"
	MethodPayPal Method = "paypal"
	MethodCrypto Method = "crypto"
)

// Payment represents a payment transaction
type Payment struct {
	ID                uuid.UUID
	OrderID           uuid.UUID
	UserID            uuid.UUID
	Amount            float64
	Currency          string
	Status            Status
	Method            Method
	TransactionID     string
	GatewayReference  string
	FailureReason     string
	RefundedAmount    float64
	RefundedAt        *time.Time
	Metadata          map[string]interface{}
	CreatedAt         time.Time
	UpdatedAt         time.Time
}

// PaymentMethod represents a saved payment method
type PaymentMethod struct {
	ID         uuid.UUID
	UserID     uuid.UUID
	Type       Method
	Provider   string // 'stripe', 'paypal', etc.
	MethodRef  string // Tokenized reference
	IsDefault  bool
	Last4      string
	ExpiryDate *time.Time
	CreatedAt  time.Time
	UpdatedAt  time.Time
}

// PaymentIntent represents a payment intent (before confirmation)
type PaymentIntent struct {
	ID            uuid.UUID
	UserID        uuid.UUID
	Amount        float64
	Currency      string
	Status        string // 'requires_payment_method', 'requires_confirmation', etc.
	ClientSecret  string
	PaymentMethod *PaymentMethod
	CreatedAt     time.Time
	ExpiresAt     time.Time
}

// Gateway defines the payment gateway interface
type Gateway interface {
	// Payment operations
	CreatePaymentIntent(ctx context.Context, amount int64, currency string, metadata map[string]string) (*PaymentIntent, error)
	ConfirmPayment(ctx context.Context, paymentIntentID string) (*Payment, error)
	RefundPayment(ctx context.Context, chargeID string, amount int64) (*Payment, error)
	
	// Payment methods
	CreateCustomer(ctx context.Context, email, name string) (string, error)
	SavePaymentMethod(ctx context.Context, customerID, paymentMethodID string) (*PaymentMethod, error)
	RemovePaymentMethod(ctx context.Context, methodID string) error
	
	// Webhooks
	ValidateWebhook(payload []byte, signature string) (bool, map[string]interface{}, error)
}

// Repository defines payment repository interface
type Repository interface {
	CreatePayment(ctx context.Context, payment *Payment) error
	UpdatePayment(ctx context.Context, payment *Payment) error
	GetPaymentByID(ctx context.Context, id uuid.UUID) (*Payment, error)
	GetPaymentByTransactionID(ctx context.Context, transactionID string) (*Payment, error)
	GetPaymentsByUser(ctx context.Context, userID uuid.UUID, page, pageSize int) ([]*Payment, int, error)
	GetPaymentsByOrder(ctx context.Context, orderID uuid.UUID) ([]*Payment, error)
	
	// Payment methods
	SavePaymentMethod(ctx context.Context, method *PaymentMethod) error
	DeletePaymentMethod(ctx context.Context, id uuid.UUID) error
	GetPaymentMethodByID(ctx context.Context, id uuid.UUID) (*PaymentMethod, error)
	GetPaymentMethodsByUser(ctx context.Context, userID uuid.UUID) ([]*PaymentMethod, error)
	SetDefaultPaymentMethod(ctx context.Context, userID, methodID uuid.UUID) error
}
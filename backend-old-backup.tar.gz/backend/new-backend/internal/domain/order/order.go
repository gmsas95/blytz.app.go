package order

import (
	"context"
	"errors"
	"time"

	"github.com/google/uuid"
)

// Status represents order status
type Status string

const (
	StatusPending    Status = "pending"
	StatusProcessing Status = "processing"
	StatusShipped    Status = "shipped"
	StatusDelivered  Status = "delivered"
	StatusCancelled  Status = "cancelled"
	StatusRefunded   Status = "refunded"
)

// Order represents a customer order
type Order struct {
	ID              uuid.UUID
	UserID          uuid.UUID
	AuctionID       *uuid.UUID // Optional - if from auction
	Status          Status
	TotalAmount     float64
	Subtotal        float64
	TaxAmount       float64
	ShippingCost    float64
	DiscountAmount  float64
	ShippingAddress *Address
	BillingAddress  *Address
	PaymentID       *uuid.UUID
	TrackingNumber  string
	Notes           string
	Items           []*OrderItem
	CreatedAt       time.Time
	UpdatedAt       time.Time
}

// CalculateTotals recalculates order totals
func (o *Order) CalculateTotals() {
	o.Subtotal = 0
	for _, item := range o.Items {
		o.Subtotal += item.Total
	}
	o.TotalAmount = o.Subtotal + o.TaxAmount + o.ShippingCost - o.DiscountAmount
}

// CanCancel checks if order can be cancelled
func (o *Order) CanCancel() bool {
	return o.Status == StatusPending || o.Status == StatusProcessing
}

// Cancel cancels the order
func (o *Order) Cancel() error {
	if !o.CanCancel() {
		return errors.New("order cannot be cancelled")
	}
	o.Status = StatusCancelled
	o.UpdatedAt = time.Now()
	return nil
}

// OrderItem represents an item in an order
type OrderItem struct {
	ID        uuid.UUID
	OrderID   uuid.UUID
	ProductID uuid.UUID
	Quantity  int
	UnitPrice float64
	Total     float64
}

// Address represents a shipping/billing address
type Address struct {
	FirstName    string
	LastName     string
	Company      string
	AddressLine1 string
	AddressLine2 string
	City         string
	State        string
	PostalCode   string
	Country      string
	Phone        string
}

// Cart represents a shopping cart
type Cart struct {
	ID        uuid.UUID
	UserID    *uuid.UUID // nil for guest carts
	Token     string     // For guest identification
	ExpiresAt time.Time
	Items     []*CartItem
	CreatedAt time.Time
	UpdatedAt time.Time
}

// CartItem represents an item in cart
type CartItem struct {
	ID        uuid.UUID
	CartID    uuid.UUID
	ProductID uuid.UUID
	Quantity  int
	AddedAt   time.Time
}

// CalculateTotal calculates cart total
func (c *Cart) CalculateTotal(products map[uuid.UUID]float64) float64 {
	total := 0.0
	for _, item := range c.Items {
		if price, ok := products[item.ProductID]; ok {
			total += price * float64(item.Quantity)
		}
	}
	return total
}

// Repository defines order repository interface
type Repository interface {
	// Orders
	CreateOrder(ctx context.Context, order *Order) error
	UpdateOrder(ctx context.Context, order *Order) error
	GetOrderByID(ctx context.Context, id uuid.UUID) (*Order, error)
	GetOrdersByUser(ctx context.Context, userID uuid.UUID, page, pageSize int) ([]*Order, int, error)
	GetOrdersBySeller(ctx context.Context, sellerID uuid.UUID, page, pageSize int) ([]*Order, int, error)
	
	// Cart
	CreateCart(ctx context.Context, cart *Cart) error
	UpdateCart(ctx context.Context, cart *Cart) error
	GetCartByID(ctx context.Context, id uuid.UUID) (*Cart, error)
	GetCartByUser(ctx context.Context, userID uuid.UUID) (*Cart, error)
	GetCartByToken(ctx context.Context, token string) (*Cart, error)
	DeleteCart(ctx context.Context, id uuid.UUID) error
	AddCartItem(ctx context.Context, item *CartItem) error
	UpdateCartItem(ctx context.Context, item *CartItem) error
	RemoveCartItem(ctx context.Context, itemID uuid.UUID) error
	ClearCart(ctx context.Context, cartID uuid.UUID) error
}
package user

import (
	"context"
	"errors"
	"time"

	"github.com/google/uuid"
)

// Role represents user role
type Role string

const (
	RoleBuyer  Role = "buyer"
	RoleSeller Role = "seller"
	RoleAdmin  Role = "admin"
)

// User represents a user in the system
type User struct {
	ID            uuid.UUID
	Email         string
	PasswordHash  string
	Role          Role
	FirstName     string
	LastName      string
	AvatarURL     string
	Phone         string
	EmailVerified bool
	LastLoginAt   *time.Time
	CreatedAt     time.Time
	UpdatedAt     time.Time
}

// CanBid checks if user can place bids
func (u *User) CanBid() bool {
	return u.Role == RoleBuyer || u.Role == RoleAdmin
}

// CanSell checks if user can create auctions
func (u *User) CanSell() bool {
	return u.Role == RoleSeller || u.Role == RoleAdmin
}

// Repository defines the user repository interface
type Repository interface {
	Create(ctx context.Context, user *User) error
	Update(ctx context.Context, user *User) error
	GetByID(ctx context.Context, id uuid.UUID) (*User, error)
	GetByEmail(ctx context.Context, email string) (*User, error)
	ExistsByEmail(ctx context.Context, email string) (bool, error)
}

// PasswordVerifier defines password verification
type PasswordVerifier interface {
	Hash(password string) (string, error)
	Verify(hash, password string) bool
}

// TokenManager defines JWT token operations
type TokenManager interface {
	Generate(userID uuid.UUID, email string, role Role) (accessToken, refreshToken string, err error)
	Validate(token string) (*TokenClaims, error)
}

// TokenClaims represents JWT claims
type TokenClaims struct {
	UserID uuid.UUID
	Email  string
	Role   Role
}

// Session represents a user session
type Session struct {
	ID           uuid.UUID
	UserID       uuid.UUID
	Token        string
	RefreshToken string
	ExpiresAt    time.Time
	CreatedAt    time.Time
}

var (
	ErrUserNotFound      = errors.New("user not found")
	ErrEmailExists       = errors.New("email already exists")
	ErrInvalidPassword   = errors.New("invalid password")
	ErrInvalidToken      = errors.New("invalid token")
	ErrSessionExpired    = errors.New("session expired")
)
package app

import (
	"context"
	"fmt"
	"log"
	"time"

	"github.com/blytz/live/backend/new-backend/internal/infrastructure/cache/redis"
	redisMessaging "github.com/blytz/live/backend/new-backend/internal/infrastructure/messaging/redis"
	"github.com/blytz/live/backend/new-backend/internal/infrastructure/persistence/postgres"
	"golang.org/x/sync/errgroup"
	"gorm.io/gorm"
)

// Application is the main application container
type Application struct {
	config   *Config
	db       *gorm.DB
	redis    *redis.Client
	eventBus *redisMessaging.EventBus
	
	// Services
	services *Services
	
	// HTTP server
	httpServer *HTTPServer
	
	// WebSocket hub
	wsHub *WebSocketHub
}

// Config holds application configuration
type Config struct {
	Environment string
	Port        string
	Database    postgres.Config
	Redis       redis.Config
	JWTSecret   string
}

// Services holds all domain services
type Services struct {
	// Will be populated as we implement services
}

// New creates a new Application instance
func New(cfg *Config) (*Application, error) {
	app := &Application{
		config: cfg,
	}

	// Initialize dependencies
	if err := app.initDatabase(); err != nil {
		return nil, fmt.Errorf("failed to initialize database: %w", err)
	}

	if err := app.initRedis(); err != nil {
		return nil, fmt.Errorf("failed to initialize Redis: %w", err)
	}

	if err := app.initEventBus(); err != nil {
		return nil, fmt.Errorf("failed to initialize event bus: %w", err)
	}

	if err := app.initServices(); err != nil {
		return nil, fmt.Errorf("failed to initialize services: %w", err)
	}

	if err := app.initHTTPServer(); err != nil {
		return nil, fmt.Errorf("failed to initialize HTTP server: %w", err)
	}

	if err := app.initWebSocketHub(); err != nil {
		return nil, fmt.Errorf("failed to initialize WebSocket hub: %w", err)
	}

	return app, nil
}

// Run starts the application and blocks until shutdown
func (a *Application) Run(ctx context.Context) error {
	log.Println("Starting application...")

	g, ctx := errgroup.WithContext(ctx)

	// Start HTTP server
	g.Go(func() error {
		log.Printf("HTTP server starting on port %s", a.config.Port)
		return a.httpServer.Start(ctx)
	})

	// Start WebSocket hub
	g.Go(func() error {
		log.Println("WebSocket hub starting...")
		return a.wsHub.Start(ctx)
	})

	// Start event consumer
	g.Go(func() error {
		log.Println("Event consumer starting...")
		return a.startEventConsumer(ctx)
	})

	// Wait for shutdown signal
	<-ctx.Done()
	log.Println("Shutdown signal received, gracefully stopping...")

	// Give services time to finish
	shutdownCtx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	if err := a.Shutdown(shutdownCtx); err != nil {
		log.Printf("Error during shutdown: %v", err)
	}

	return g.Wait()
}

// Shutdown gracefully shuts down the application
func (a *Application) Shutdown(ctx context.Context) error {
	var errs []error

	if a.httpServer != nil {
		if err := a.httpServer.Shutdown(ctx); err != nil {
			errs = append(errs, fmt.Errorf("http server shutdown: %w", err))
		}
	}

	if a.wsHub != nil {
		if err := a.wsHub.Shutdown(ctx); err != nil {
			errs = append(errs, fmt.Errorf("websocket hub shutdown: %w", err))
		}
	}

	if a.redis != nil {
		if err := a.redis.Close(); err != nil {
			errs = append(errs, fmt.Errorf("redis close: %w", err))
		}
	}

	if a.db != nil {
		sqlDB, err := a.db.DB()
		if err == nil {
			if err := sqlDB.Close(); err != nil {
				errs = append(errs, fmt.Errorf("database close: %w", err))
			}
		}
	}

	if len(errs) > 0 {
		return fmt.Errorf("shutdown errors: %v", errs)
	}

	return nil
}

// initDatabase initializes the database connection
func (a *Application) initDatabase() error {
	db, err := postgres.NewConnection(a.config.Database)
	if err != nil {
		return err
	}

	// Run migrations
	if err := postgres.AutoMigrate(db); err != nil {
		return fmt.Errorf("failed to run migrations: %w", err)
	}

	a.db = db
	log.Println("Database connected and migrated")
	return nil
}

// initRedis initializes Redis connection
func (a *Application) initRedis() error {
	client, err := redis.NewClient(a.config.Redis)
	if err != nil {
		return err
	}

	a.redis = client
	log.Println("Redis connected")
	return nil
}

// initEventBus initializes the event bus
func (a *Application) initEventBus() error {
	a.eventBus = redisMessaging.NewEventBus(a.redis.GetClient())
	log.Println("Event bus initialized")
	return nil
}

// initServices initializes domain services
func (a *Application) initServices() error {
	// TODO: Initialize services once implemented
	a.services = &Services{}
	log.Println("Services initialized")
	return nil
}

// initHTTPServer initializes the HTTP server
func (a *Application) initHTTPServer() error {
	// TODO: Implement HTTP server initialization
	a.httpServer = NewHTTPServer(a.config.Port, nil) // Pass handlers
	return nil
}

// initWebSocketHub initializes the WebSocket hub
func (a *Application) initWebSocketHub() error {
	// TODO: Implement WebSocket hub initialization
	a.wsHub = NewWebSocketHub(a.redis.GetClient(), a.eventBus)
	return nil
}

// startEventConsumer starts consuming events
func (a *Application) startEventConsumer(ctx context.Context) error {
	// TODO: Implement event consumption
	<-ctx.Done()
	return nil
}